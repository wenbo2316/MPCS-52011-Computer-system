import sys
import re

fname = sys.argv[1]
prefix = fname.split('.in')[0]

a=[]
with open(f'{prefix}.in', mode = 'r') as f:
    for line in f.readlines():
        s = line.replace(' ','')
        s = re.sub('//.*', '', s)
        a.append(s)


with open(f'{prefix}.out', mode = 'w') as k:
    comment = False
    for i in a:
        if re.match(r"^//*.*", i):
            comment = True
        elif re.match(r".*/*/\n", i):
            comment = False
        elif comment:
            pass
        else:
            k.write(i)