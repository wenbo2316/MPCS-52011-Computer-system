This is a python language programming named myasembler. 
It requires an input asm file and an output hack file and convert assembly language to machine language.