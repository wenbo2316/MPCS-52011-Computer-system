Run: python vmtranslate.py test.vm
It will create a test.asm file