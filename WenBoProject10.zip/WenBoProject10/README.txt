Wen Bo

This project was modeled on the JackAnalyzer module described in 
section 10.3.1 of the textbook. 

To run this code, simply enter the name of the python
program followed by the path to the .jack input file on the command line.
After execution, the xml output files will be saved to a directory
named "xml" within the same directory as the .jack file.

Example run:

	JackAnalyzer.py ArrayTest/Main.jack

Output:

	FINISHED
	xml files saved to directory ArrayTest/xml

Following execution, Main.xml and MainT.xml will be saved in the xml
directory within the ArrayTest directory.
